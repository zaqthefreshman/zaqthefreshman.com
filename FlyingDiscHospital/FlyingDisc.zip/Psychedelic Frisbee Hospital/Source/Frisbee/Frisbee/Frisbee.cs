﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace Engine
{
    public class Frisbee : Mass
    {
        #region Members

		private Texture2D tex;
		private Effect VPT;
		private V.PT[] Vs;
		private int[] Is;
		public bool OnGround = false;

        #endregion

        #region Constructor

        public Frisbee(ContentManager Content, Vector2 Pos) : base(Pos)
        {
			this.tex = Content.Load<Texture2D>("frisbee");
			this.VPT = Content.Load<Effect>("vpt");

			this.Vs = new V.PT[] 
			{ 
				new V.PT(new Vector3(0, 0, 0), new Vector2(0.0f, 0.0f)),
				new V.PT(new Vector3(this.tex.Width, 0, 0), new Vector2(1.0f, 0.0f)),
				new V.PT(new Vector3(this.tex.Width, this.tex.Height, 0), new Vector2(1.0f, 1.0f)),
				new V.PT(new Vector3(0, this.tex.Height, 0), new Vector2(0.0f, 1.0f)),
			};

			this.Is = new int[] { 0, 1, 2, 2, 3, 0 };
        }

        #endregion

        #region Update

        public override void Update()
        {
			base.Update();
			if (OnGround)
			{
				Velocity *= 0.85f;
			}
			else
			{
				Velocity *= 0.98f;
			}
			if (Position.Y > Graphics.Height - tex.Height)
			{
				OnGround = true;
				Position.Y = Graphics.Height - tex.Height;
				Velocity.Y = 0;
				Acceleration.Y = 0;
			}
			if (Position.X > Graphics.Width - tex.Width)
			{
				Position.X = Graphics.Width - tex.Width;
				Velocity.X = 0;
				Acceleration.X = 0;
			}
			if (Position.X < 0)
			{
				Position.X = 0;
				Velocity.X = 0;
				Acceleration.X = 0;
			}
		}

        #endregion

        #region Draw

        public void Draw(Camera cam)
        {
			VPT.Parameters["W"].SetValue(Matrix.CreateTranslation(new Vector3(Position, 0)));
			VPT.Parameters["P"].SetValue(cam.Proj);
			VPT.Parameters["Texture"].SetValue(tex);
			VPT.CurrentTechnique.Passes[0].Apply();

			Graphics.Device.DrawUserIndexedPrimitives(PrimitiveType.TriangleList, Vs, 0, Vs.Length, Is, 0, 2);
        }

        #endregion

        #region Methods

        #endregion
    }
}
