﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Media;

namespace Engine
{
	public class Player : Mass
    {
        #region Members

		public Frisbee fuckkevin;
		private Texture2D tex;
		private Effect VPT;
		private Effect VPC;
		private V.PT[] Vs;
		private int[] Is;

		private bool left;

		private bool OnGround = false;

		private PowerBar pb = null;

		public bool Holding;

		public Keys[] keys;

		public float leftb;
		public float rightb;

		public int Points = 0;


        #endregion

        #region Constructor

        public Player(ContentManager Content, Texture2D tex, Vector2 Pos, Frisbee f) : base(Pos)
        {
			this.fuckkevin = f;
			this.tex = tex;
			this.VPT = Content.Load<Effect>("vpt");
			this.VPC = Content.Load<Effect>("vpc");

			this.Vs = new V.PT[] 
				{ 
					new V.PT(new Vector3(0, 0, 0), new Vector2(0.0f, 0.0f)),
					new V.PT(new Vector3(this.tex.Width, 0, 0), new Vector2(1.0f, 0.0f)),
					new V.PT(new Vector3(this.tex.Width, this.tex.Height, 0), new Vector2(1.0f, 1.0f)),
					new V.PT(new Vector3(0, this.tex.Height, 0), new Vector2(0.0f, 1.0f)),
				};

			this.Is = new int[] { 0, 1, 2, 2, 3, 0 };

			pb = new PowerBar(Pos - new Vector2(2, 10));
        }

        #endregion

        #region Update

		public override void Update()
		{
			#region Input

			if (Input.Keyboard.Current.KeyDown(keys[0]) && !Input.Keyboard.Current.KeyDown(keys[1]))
			{
				Acceleration = new Vector2(-1.0f, 0.0f);
				if (left)
				{
					left = false;
					pb.Power += 200 / (pb.Power + 30) + 10f;
				}
			}

			if (Input.Keyboard.Current.KeyDown(keys[1]) && !Input.Keyboard.Current.KeyDown(keys[0]))
			{
				Acceleration = new Vector2(1.0f, 0.0f);
				if (!left)
				{
					left = true;
					pb.Power += 200 / (pb.Power + 30) + 10f;
				}
			}

			if (Input.Keyboard.Current.KeyDown(keys[2]) && OnGround) { OnGround = false; Acceleration = new Vector2(0.0f, -40.0f); }
			//if(Input.Keyboard.Current.KeyDown(Keys.Left)) Acceleration = new Vector2(0.0f, 0.0f);

			if (Input.Keyboard.KeyPressed(keys[3]) && Vector2.Distance(Position + new Vector2(32, 80), fuckkevin.Position + new Vector2(10, 5)) < 80 && !Holding)
			{
				
					fuckkevin.OnGround = false;
					Holding = true; //account for the other player holding the fris
					if (keys[0] == Keys.A) Main.last = 2; else Main.last = 1;
				
			}
			else if(Input.Keyboard.KeyPressed(keys[3]) && Holding)
			{
				Holding = false;
				if (this.Vs[0].Tex.X == 0.0f)
				{
					fuckkevin.OnGround = false;
					fuckkevin.Velocity = new Vector2((pb.Power / 7 + 3) * 2, (- 15));
				}
				else
				{
					fuckkevin.OnGround = false;
					fuckkevin.Velocity = new Vector2((pb.Power / -7 - 3) * 2, (- 15));
				}
			}
			#endregion

			#region Verts
			if (Acceleration.X > 0.01f)
			{
				this.Vs = new V.PT[] 
				{ 
					new V.PT(new Vector3(0, 0, 0), new Vector2(0.0f, 0.0f)),
					new V.PT(new Vector3(this.tex.Width, 0, 0), new Vector2(1.0f, 0.0f)),
					new V.PT(new Vector3(this.tex.Width, this.tex.Height, 0), new Vector2(1.0f, 1.0f)),
					new V.PT(new Vector3(0, this.tex.Height, 0), new Vector2(0.0f, 1.0f)),
				};

			}
			else if (Acceleration.X < -0.01f)
			{
				this.Vs = new V.PT[] 
				{ 
					new V.PT(new Vector3(0, 0, 0), new Vector2(1.0f, 0.0f)),
					new V.PT(new Vector3(this.tex.Width, 0, 0), new Vector2(0.0f, 0.0f)),
					new V.PT(new Vector3(this.tex.Width, this.tex.Height, 0), new Vector2(0.0f, 1.0f)),
					new V.PT(new Vector3(0, this.tex.Height, 0), new Vector2(1.0f, 1.0f)),
				};

			}
			if (this.Vs[0].Tex.X == 0.0f)
			{
				if (Holding)
				{
					fuckkevin.Position = Position + new Vector2(60, 76);
					fuckkevin.Velocity = Vector2.Zero;
					fuckkevin.Acceleration = Vector2.Zero;
				};
			}
			else
			{
				if (Holding)
				{
					fuckkevin.Position = Position + new Vector2(-28, 76);
					fuckkevin.Velocity = Vector2.Zero;
					fuckkevin.Acceleration = Vector2.Zero;
				}
			}
			#endregion

			#region Power

			pb.Pos = Position - new Vector2(2, 10);
			pb.Power -= 1f;

			#endregion

			base.Update();

			#region Correct Physics

			if (OnGround)
			{
				Velocity *= 0.90f;
			}
			else
			{
				Velocity *= 0.90f;
			}
			if (Position.Y > Graphics.Height - tex.Height)
			{
				OnGround = true;
				Position.Y = Graphics.Height - tex.Height;
				Velocity.Y = 0;
				Acceleration.Y = 0;
			}
			if (Position.X > rightb - tex.Width)
			{
				Position.X = rightb - tex.Width;
				Velocity.X = 0;
				Acceleration.X = 0;
			}
			if (Position.X < leftb)
			{
				Position.X = leftb;
				Velocity.X = 0;
				Acceleration.X = 0;
			}

			#endregion
		}

        #endregion

        #region Draw

		public void Draw(Camera cam)
		{
			VPT.Parameters["W"].SetValue(Matrix.CreateTranslation(new Vector3(Position, 0)));
			VPT.Parameters["P"].SetValue(cam.Proj);
			VPT.Parameters["Texture"].SetValue(tex);
			VPT.CurrentTechnique.Passes[0].Apply();

			Graphics.Device.DrawUserIndexedPrimitives(PrimitiveType.TriangleList, Vs, 0, Vs.Length, Is, 0, 2);

			pb.Draw(VPC, cam);
		}

        #endregion

        #region Methods

        #endregion
    }
}
