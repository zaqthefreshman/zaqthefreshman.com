﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Audio;

namespace Engine
{
    public class Main : Screen
    {
        #region Members

		SpriteBatch batch = new SpriteBatch(Graphics.Device);
		private Camera cam = new Camera(new Vector2(Graphics.Width / 2, Graphics.Height / 2));
		private Player[] p;
		private Frisbee fris;
		private Texture2D back;
		private Effect Trippy;
		public Song song;

		private SpriteFont font;

		public static int last;

        #endregion

        #region Initialize

        public override void Initialize()
        {

        }

        #endregion

        #region Load Content

        public override void LoadContent()
        {
			fris = new Frisbee(Content, new Vector2(100, 300));

			song = Content.Load<Song>("Gangnam Style");

			#region Players
			p = new Player[2];
			p[0] = new Player(Content, Content.Load<Texture2D>("Player/zaq"), new Vector2(200, 500), fris);
			p[0].keys = new Keys[4];
			p[0].keys[0] = Keys.Left;
			p[0].keys[1] = Keys.Right;
			p[0].keys[2] = Keys.Up;
			p[0].keys[3] = Keys.RightShift;

			p[0].leftb = Graphics.Width - 65 - 200;
			p[0].rightb = Graphics.Width;

			p[1] = new Player(Content, Content.Load<Texture2D>("Player/kevin"), new Vector2(200, 500), fris);
			p[1].keys = new Keys[4];
			p[1].keys[0] = Keys.A;
			p[1].keys[1] = Keys.D;
			p[1].keys[2] = Keys.W;
			p[1].keys[3] = Keys.LeftShift;


			p[1].leftb = 0;
			p[1].rightb = 0 + 65 + 200;
			#endregion

			this.back = Content.Load<Texture2D>("background");
			this.Trippy = Content.Load<Effect>("trippy");

			this.font = Content.Load<SpriteFont>("SpriteFont1");

            
            MediaPlayer.IsRepeating = true;
            MediaPlayer.Play(song);

			ContentLoaded = true;
        }

        #endregion

        #region Unload Content

        public override void UnloadContent()
        {
            Content.Unload();
            ContentLoaded = false;
        }

        #endregion

        #region Update

        public override void Update(GameTime gameTime)
        {
            if (Updates)
			{
				foreach (Player pa in p) pa.Update();
				fris.Update();
				if (fris.Position.X > 265 && fris.Position.X < Graphics.Width - 265 && fris.OnGround)
				{
					if (last == 2)
					{
						p[0].Points++;
						RFris();
					}
					else if (last == 1) 
					{
						p[1].Points++;
						RFris();
					}
				}
				else if (fris.Position.X <= 265 && last != 0 && fris.OnGround)
				{
					p[0].Points++;
					RFris();
				}
				else if (fris.Position.X >= Graphics.Width - 265 && last != 0 && fris.OnGround)
				{
					p[1].Points++;
					RFris();
				}
            }
        }

        #endregion

        #region Draw

        public override void Draw(GameTime gameTime)
        {
            if (Draws)
            {
				Graphics.Device.Clear(Color.Black);

				Trippy.Parameters["W"].SetValue(Matrix.CreateTranslation(new Vector3(-14, -5, 0)));
				Trippy.Parameters["P"].SetValue(cam.Proj);

				Trippy.Parameters["Texture"].SetValue(back);

				Trippy.Parameters["fp"].SetValue(fris.Position);
				Trippy.Parameters["fv"].SetValue(fris.Velocity);

				Trippy.Parameters["time"].SetValue(gameTime.TotalGameTime.Milliseconds);

				Trippy.CurrentTechnique.Passes[0].Apply();

				Graphics.Device.DrawUserIndexedPrimitives(PrimitiveType.TriangleList, new V.PT[] { new V.PT(new Vector3(0, 0, 0), new Vector2(0, 0)), new V.PT(new Vector3(back.Width, 0, 0), new Vector2(1, 0)), new V.PT(new Vector3(back.Width, back.Height, 0), new Vector2(1, 1)), new V.PT(new Vector3(0, back.Height, 0), new Vector2(0, 1)) }, 0, 4, new int[] { 0, 1, 2, 2, 3, 0 }, 0, 2);

				foreach (Player pa in p) pa.Draw(cam);
				fris.Draw(cam);
				batch.Begin();
				batch.DrawString(font, p[1].Points.ToString(), new Vector2(20, 20), Color.LimeGreen);
				batch.DrawString(font, p[0].Points.ToString(), new Vector2(1215, 20), Color.LimeGreen);
				batch.End();
            }
        }

        #endregion

		private void RFris()
		{
			last = 0;
			if (p[0].Points < p[1].Points) fris = new Frisbee(Content, new Vector2(1050, 300)); else fris = new Frisbee(Content, new Vector2(100, 300));
			p[0].fuckkevin = fris;
			p[1].fuckkevin = fris;
		}

    }
}
