﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Engine
{
    #region Graphics

    public static class Graphics
    {
        public static GraphicsDeviceManager Manager { get { return Game1.Manager; } }
        public static GraphicsDevice Device { get { return Game1.Manager.GraphicsDevice; } }

        public static int Width { get { return Device.Viewport.Width; } }
        public static int Height { get { return Device.Viewport.Height; } }
    }

    #endregion

	#region Camera

	public class Camera
	{
		public Vector2 Pos;
		public Matrix Proj;

		public Camera(Vector2 Pos)
		{
			this.Pos = Pos;
			Update();
		}

		public void Update()
		{
			this.Proj = Matrix.CreateOrthographicOffCenter(Pos.X - Graphics.Width / 2, Pos.X + Graphics.Width / 2, Pos.Y + Graphics.Height / 2, Pos.Y - Graphics.Height / 2, 0.0f, 1.0f);
		}
	}

	#endregion

	#region Vertex Formats

	public struct V
    {
        #region Position

        public struct P : IVertexType
        {
            public Vector3 Pos;

            VertexDeclaration IVertexType.VertexDeclaration { get { return VertexDeclaration; } }

            public P(Vector3 Pos)
            {
                this.Pos = Pos;
            }

            public static readonly VertexDeclaration VertexDeclaration = new VertexDeclaration
            (
            new VertexElement(0, VertexElementFormat.Vector3, VertexElementUsage.Position, 0)
            );
        }

        #endregion

        #region Position Color

        public struct PC : IVertexType
        {
            public Vector3 Pos;
            public Vector4 Col;

            VertexDeclaration IVertexType.VertexDeclaration { get { return VertexDeclaration; } }

            public PC(Vector3 Pos, Vector4 Col)
            {
                this.Pos = Pos;
                this.Col = Col;
            }

            public static readonly VertexDeclaration VertexDeclaration = new VertexDeclaration
            (
            new VertexElement(0, VertexElementFormat.Vector3, VertexElementUsage.Position, 0),
            new VertexElement(12, VertexElementFormat.Vector4, VertexElementUsage.Color, 0)
            );
        }

        #endregion

        #region Position Texture

        public struct PT : IVertexType
        {
            public Vector3 Pos;
            public Vector2 Tex;

            VertexDeclaration IVertexType.VertexDeclaration { get { return VertexDeclaration; } }

            public PT(Vector3 Pos, Vector2 Tex)
            {
                this.Pos = Pos;
                this.Tex = Tex;
            }

            public static readonly VertexDeclaration VertexDeclaration = new VertexDeclaration
            (
            new VertexElement(0, VertexElementFormat.Vector3, VertexElementUsage.Position, 0),
            new VertexElement(12, VertexElementFormat.Vector2, VertexElementUsage.TextureCoordinate, 0)
            );
        }

        #endregion

        #region Position Color Texture

        public struct PCT : IVertexType
        {
            public Vector3 Pos;
            public Vector4 Col;
            public Vector2 Tex;

            VertexDeclaration IVertexType.VertexDeclaration { get { return VertexDeclaration; } }

            public PCT(Vector3 Pos, Vector4 Col, Vector2 Tex)
            {
                this.Pos = Pos;
                this.Col = Col;
                this.Tex = Tex;
            }

            public static readonly VertexDeclaration VertexDeclaration = new VertexDeclaration
            (
            new VertexElement(00, VertexElementFormat.Vector3, VertexElementUsage.Position, 0),
            new VertexElement(12, VertexElementFormat.Vector4, VertexElementUsage.Color, 0),
            new VertexElement(28, VertexElementFormat.Vector2, VertexElementUsage.TextureCoordinate, 0)
            );
        }

        #endregion

        #region Position Color Normal Texture

        public struct PNT : IVertexType
        {
            public Vector3 Pos;
            public Vector3 Nml;
            public Vector2 Tex;

            VertexDeclaration IVertexType.VertexDeclaration { get { return VertexDeclaration; } }

            public PNT(Vector3 Pos, Vector3 Nml, Vector2 Tex)
            {
                this.Pos = Pos;
                this.Nml = Nml;
                this.Tex = Tex;
            }

            public static readonly VertexDeclaration VertexDeclaration = new VertexDeclaration
            (
            new VertexElement(00, VertexElementFormat.Vector3, VertexElementUsage.Position, 0),
            new VertexElement(12, VertexElementFormat.Vector3, VertexElementUsage.Normal, 0),
            new VertexElement(24, VertexElementFormat.Vector2, VertexElementUsage.TextureCoordinate, 0)
            );
        }

        #endregion

        #region HalfVec Texture

        public struct HVT : IVertexType
        {
            public Vector2 Pos;
            public Vector2 Tex;

            VertexDeclaration IVertexType.VertexDeclaration { get { return VertexDeclaration; } }

            public HVT(Vector2 Pos, Vector2 Tex)
            {
                this.Pos = Pos;
                this.Tex = Tex;
            }

            public static readonly VertexDeclaration VertexDeclaration = new VertexDeclaration
            (
            new VertexElement(0, VertexElementFormat.Vector2, VertexElementUsage.Position, 0),
            new VertexElement(2, VertexElementFormat.Vector2, VertexElementUsage.Position, 0)
            );
        }

        #endregion
    }

    public struct iV
    {
        #region P

        public struct HVT
        {

            public static readonly VertexDeclaration Declaration = new VertexDeclaration
            (
                new VertexElement(0, VertexElementFormat.Vector4, VertexElementUsage.Position, 0)
            );

        }

        #endregion
    }

    #endregion
}
