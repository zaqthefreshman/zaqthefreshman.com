﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Engine
{
    public class PowerBar
    {
        #region Members

		private V.PC[] BVs;
		private V.PC[] Vs;
		private int[] Is;

		public Vector2 Pos;
		public float Power;

        #endregion

        #region Constructor

        public PowerBar(Vector2 Pos)
        {
			this.BVs = new V.PC[]
			{
				new V.PC(new Vector3(0.0f, 0.0f, 0.0f), new Vector4(0.0f, 0.0f, 0.0f, 1.0f)),
				new V.PC(new Vector3(120.0f, 0.0f, 0.0f), new Vector4(0.0f, 0.0f, 0.0f, 1.0f)),
				new V.PC(new Vector3(120.0f, 20.0f, 0.0f), new Vector4(0.0f, 0.0f, 0.0f, 1.0f)),
				new V.PC(new Vector3(0.0f, 20.0f, 0.0f), new Vector4(0.0f, 0.0f, 0.0f, 1.0f))
			};

			this.Is = new int[]
			{
				0, 1, 2, 2, 3, 0
			};


        }

        #endregion

        #region Draw

        public void Draw(Effect VPC, Camera cam)
        {
			if (Power > 118) Power = 118;
			if (Power < 2) Power = 2;

			if (Power > 2)
			{
				Vs = new V.PC[]
				{
				new V.PC(new Vector3(2, 2, 0), new Vector4(0.0f, 1.0f, 0.0f, 1.0f)),
				new V.PC(new Vector3(Power, 2, 0), new Vector4(0.0f, 1.0f, 0.0f, 1.0f)),
				new V.PC(new Vector3(Power, 18, 0), new Vector4(0.0f, 1.0f, 0.0f, 1.0f)),
				new V.PC(new Vector3(2, 18, 0), new Vector4(0.0f, 1.0f, 0.0f, 1.0f))
				};

				VPC.Parameters["W"].SetValue(Matrix.CreateTranslation(new Vector3(Pos, 0)));
				VPC.Parameters["P"].SetValue(cam.Proj);

				VPC.CurrentTechnique.Passes[0].Apply();

				Graphics.Device.DrawUserIndexedPrimitives(PrimitiveType.TriangleList, BVs, 0, BVs.Length, Is, 0, 2);
				Graphics.Device.DrawUserIndexedPrimitives(PrimitiveType.TriangleList, Vs, 0, Vs.Length, Is, 0, 2);
			}
        }

        #endregion

        #region Methods

        #endregion
    }
}
