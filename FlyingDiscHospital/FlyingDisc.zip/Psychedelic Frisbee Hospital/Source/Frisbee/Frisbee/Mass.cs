using System;
using System.Collections.Generic;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace Engine
{
    public class Mass
    {
        #region Members
        //----------------------------------------------------------------------------------------------------//

        public Vector2 Position;
        public Vector2 Velocity;
        public Vector2 Acceleration;

        public static Vector2 Gravity = new Vector2(0.0f, 0.60f);
        public static Vector2 Dampening = new Vector2(0.98f, 0.99f);

        //----------------------------------------------------------------------------------------------------//
        #endregion

        #region Constructor
        //----------------------------------------------------------------------------------------------------//

        public Mass(Vector2 Position) : this(Position, Vector2.Zero) { }

        public Mass(Vector2 Position, Vector2 Velocity)
        {
            this.Position = Position;
            this.Velocity = Velocity;
            Acceleration = Vector2.Zero;
        }

        //----------------------------------------------------------------------------------------------------//
        #endregion

        #region Update
        //----------------------------------------------------------------------------------------------------//

        public virtual void Update()
        {
            Velocity += Acceleration + Gravity;
            Position += Velocity * Dampening;
            Acceleration = Vector2.Zero;
        }

        //----------------------------------------------------------------------------------------------------//
        #endregion
    }
}