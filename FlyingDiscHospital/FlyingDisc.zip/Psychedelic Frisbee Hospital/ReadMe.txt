Psychedelic Frisbee Hospital

Here's the source and build for my project during CodeDay August. You are welcome to do what you wish with the source, my apologies for the quality it was a very short term rapid prototype. 

Controls:--------------------------------------------------------------------------------

Left Player (Kevin)
W - Jump
A - Move left
D - Move right
LeftShift - Grab Frisbee/Release Frisbee

Right Player (Zaq?)
Up - Jump
Left - Move left
Right - Move right
RightShift - Grab Frisbee/Release Frisbee


GamePlay:--------------------------------------------------------------------------------

Enjoy playing frisbee with a friend during with catchy music and trippy visuals
Set your own challenges on scoring or play until you get bored (just like real frisbee)

To throw the frisbee you will need to power up your throw by hammering the left and right movements when you have enough power throw it to the other player.

Scoring:---------------------------------------------------------------------------------

Failing to throw the frisbee across the screen scores the other player a point. If you throw it across and the other player fails to catch it you gain a point.

Credits:
Song - http://www.youtube.com/watch?v=9bZkp7q19f0

Team:
Zachary Wiedmann - Programmer
Kevin Beason     - Designer/Sprite Artist
Leah Chung       - Background Artist